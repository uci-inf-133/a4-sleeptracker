--Readme document for Linxuan Xin, linxuanx@uci.edu, 11311415—

1. How long, in hours, did it take you to complete this assignment?

34 hours


2. What online resources did you consult when completing this assignment? (list specific URLs)

https://beta.ionicframework.com/docs/


3. What classmates or other individuals did you consult as part of this assignment? What did you discuss?

N/A

4. Is there anything special we need to know in order to run your code?
Install the required packages


--Aim for no more than a few sentences for each of the following questions.--


5. Did you design your app with a particular type of user in mind? If so, whom? Did you design your app specifically for iOS or Android, or both?

When designing this app, I was thinking that the core users are college students. It works on both iOS and Android system. 

6. How can a person log overnight sleep in your app? Why did you choose to support logging overnight sleep in this way?

When a person wake up, he can check the sleep time and wake up time.


7. How can a person log sleepiness during the day in your app? Why did you choose to support logging sleepiness in this way?

Users can log the sleepiness during the day when ever he would like to do it.



8. How can a person view the data they logged in your app? Why did you choose to support viewing logged data in this way?

After users click the view logged data button, they will be navigated to the view page, which shows all the sleep data as a list.


9. Did you add any "extra" features, such as other data to log or changes to the styling of the app? If so, what did you add? How do these add to the experience of the app?

N/A
