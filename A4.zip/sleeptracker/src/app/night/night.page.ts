import { Component, OnInit } from '@angular/core';
import { SleepService } from '../services/sleep.service';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-night',
  templateUrl: './night.page.html',
  styleUrls: ['./night.page.scss'],
})
export class NightPage implements OnInit {
  sleepStart:string
  sleepEnd:string
  constructor(public navCtrl: NavController, private service: SleepService) { 

  }

  ngOnInit() {
  }
  log(){
      var data = new OvernightSleepData(new Date(this.sleepStart), new Date(this.sleepEnd));
      this.service.logOvernightData(data);
      this.navCtrl.navigateForward('/home');
  }
}
