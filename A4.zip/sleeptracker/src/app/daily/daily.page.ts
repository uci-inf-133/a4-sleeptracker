import { Component, OnInit } from '@angular/core';
import { SleepService } from '../services/sleep.service';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { NavController } from '@ionic/angular';


@Component({
  selector: 'app-daily',
  templateUrl: './daily.page.html',
  styleUrls: ['./daily.page.scss'],
})
export class DailyPage implements OnInit {
  ScaleValues:String[]
  loggedValue:number=1
  loggedAt:string
  constructor(public navCtrl: NavController, private service: SleepService) { }

  ngOnInit() {
      this.ScaleValues = StanfordSleepinessData.ScaleValues.slice(1,StanfordSleepinessData.ScaleValues.length)
  }

  log() {
      var data = new StanfordSleepinessData(this.loggedValue, new Date(this.loggedAt))
      this.service.logSleepinessData(data);
      this.navCtrl.navigateForward('/home');
      console.log("logged stanford sleepiness data")
  }

}
